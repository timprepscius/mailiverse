
release_major = 1
release_minor = 10
release_patch = 3

release_vc_rev = 'mtn:7b193c2f27bc5bdbdd4297c5e53acfe4e4624bdb'
release_so_abi_rev = 0

release_datestamp = 20120710
