from _botan import *

# Initialize the library when the module is imported
init = LibraryInitializer()
